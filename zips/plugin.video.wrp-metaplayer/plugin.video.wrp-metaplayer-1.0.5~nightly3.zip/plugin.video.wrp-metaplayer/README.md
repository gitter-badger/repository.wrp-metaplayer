
# WRP-MetaPlayer Kodi Add-on


![logo](https://raw.githubusercontent.com/DWH-WFC/repository.wrp-metaplayer/master/icon.png)

***

Bei dem WRP-MetaPlayer handelt es sich um ein Video-Addon für Kodi, welches die Film und TV-Serien Informationen von TMDb und TVDb abfragt und diese in einer GUI darstellt. Mit zusätzlichen JSON Playern kann man aus verschiedenen Plugins Filme und TV Serien abspielen.

***

[![Gitter](https://badges.gitter.im/DWH-WFC-Chat/community.svg)](https://gitter.im/DWH-WFC-Chat/community?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge) Hier findet ihr Hilfe wenn es um den WRP-MetaPlayer geht.

![logo](https://s19.directupload.net/images/191117/wndc2vwe.jpg)

***

Original Source Code stammt von Chaapai by Mr. Blamo und OpenMeta by OpenProject
